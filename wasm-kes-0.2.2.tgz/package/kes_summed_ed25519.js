
let imports = {};
imports['__wbindgen_placeholder__'] = module.exports;

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
function decodeText(ptr, len) {
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let WASM_VECTOR_LEN = 0;

const KesKeypairFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_keskeypair_free(ptr >>> 0, 1));

const Sum1CompactKesSigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sum1compactkessig_free(ptr >>> 0, 1));

const Sum2CompactKesSigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sum2compactkessig_free(ptr >>> 0, 1));

const Sum3CompactKesSigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sum3compactkessig_free(ptr >>> 0, 1));

const Sum4CompactKesSigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sum4compactkessig_free(ptr >>> 0, 1));

const Sum5CompactKesSigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sum5compactkessig_free(ptr >>> 0, 1));

const Sum6CompactKesSigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sum6compactkessig_free(ptr >>> 0, 1));

const Sum7CompactKesSigFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sum7compactkessig_free(ptr >>> 0, 1));

const WasmSignatureFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmsignature_free(ptr >>> 0, 1));

/**
 * Struct for keygen result (secret key bytes and public key bytes)
 */
class KesKeypair {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(KesKeypair.prototype);
        obj.__wbg_ptr = ptr;
        KesKeypairFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        KesKeypairFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_keskeypair_free(ptr, 0);
    }
    /**
     * @returns {Uint8Array}
     */
    get sk() {
        const ret = wasm.keskeypair_sk(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {Uint8Array}
     */
    get pk() {
        const ret = wasm.keskeypair_pk(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
}
if (Symbol.dispose) KesKeypair.prototype[Symbol.dispose] = KesKeypair.prototype.free;
exports.KesKeypair = KesKeypair;

/**
 * Structure that represents a KES signature.
 */
class Sum1CompactKesSig {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Sum1CompactKesSigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sum1compactkessig_free(ptr, 0);
    }
}
if (Symbol.dispose) Sum1CompactKesSig.prototype[Symbol.dispose] = Sum1CompactKesSig.prototype.free;
exports.Sum1CompactKesSig = Sum1CompactKesSig;

/**
 * Structure that represents a KES signature.
 */
class Sum2CompactKesSig {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Sum2CompactKesSigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sum2compactkessig_free(ptr, 0);
    }
}
if (Symbol.dispose) Sum2CompactKesSig.prototype[Symbol.dispose] = Sum2CompactKesSig.prototype.free;
exports.Sum2CompactKesSig = Sum2CompactKesSig;

/**
 * Structure that represents a KES signature.
 */
class Sum3CompactKesSig {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Sum3CompactKesSigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sum3compactkessig_free(ptr, 0);
    }
}
if (Symbol.dispose) Sum3CompactKesSig.prototype[Symbol.dispose] = Sum3CompactKesSig.prototype.free;
exports.Sum3CompactKesSig = Sum3CompactKesSig;

/**
 * Structure that represents a KES signature.
 */
class Sum4CompactKesSig {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Sum4CompactKesSigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sum4compactkessig_free(ptr, 0);
    }
}
if (Symbol.dispose) Sum4CompactKesSig.prototype[Symbol.dispose] = Sum4CompactKesSig.prototype.free;
exports.Sum4CompactKesSig = Sum4CompactKesSig;

/**
 * Structure that represents a KES signature.
 */
class Sum5CompactKesSig {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Sum5CompactKesSigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sum5compactkessig_free(ptr, 0);
    }
}
if (Symbol.dispose) Sum5CompactKesSig.prototype[Symbol.dispose] = Sum5CompactKesSig.prototype.free;
exports.Sum5CompactKesSig = Sum5CompactKesSig;

/**
 * Structure that represents a KES signature.
 */
class Sum6CompactKesSig {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Sum6CompactKesSigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sum6compactkessig_free(ptr, 0);
    }
}
if (Symbol.dispose) Sum6CompactKesSig.prototype[Symbol.dispose] = Sum6CompactKesSig.prototype.free;
exports.Sum6CompactKesSig = Sum6CompactKesSig;

/**
 * Structure that represents a KES signature.
 */
class Sum7CompactKesSig {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Sum7CompactKesSigFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sum7compactkessig_free(ptr, 0);
    }
}
if (Symbol.dispose) Sum7CompactKesSig.prototype[Symbol.dispose] = Sum7CompactKesSig.prototype.free;
exports.Sum7CompactKesSig = Sum7CompactKesSig;

/**
 * cool struct
 */
class WasmSignature {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmSignature.prototype);
        obj.__wbg_ptr = ptr;
        WasmSignatureFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmSignatureFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmsignature_free(ptr, 0);
    }
}
if (Symbol.dispose) WasmSignature.prototype[Symbol.dispose] = WasmSignature.prototype.free;
exports.WasmSignature = WasmSignature;

/**
 * Gets the current period from the secret key buffer (Sum6Kes).
 * @param {Uint8Array} sk_buffer
 * @returns {number}
 */
function kes_get_period(sk_buffer) {
    const ptr0 = passArray8ToWasm0(sk_buffer, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.kes_get_period(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] >>> 0;
}
exports.kes_get_period = kes_get_period;

/**
 * Generates a depth-6 KES key pair (Sum6Kes) from a seed.
 * Returns KesKeypair with sk_bytes (full buffer including period) and pk_bytes.
 * Suitable for Cardano operational certificates.
 * @param {Uint8Array} seed
 * @returns {KesKeypair}
 */
function kes_keygen(seed) {
    var ptr0 = passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
    var len0 = WASM_VECTOR_LEN;
    const ret = wasm.kes_keygen(ptr0, len0, seed);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return KesKeypair.__wrap(ret[0]);
}
exports.kes_keygen = kes_keygen;

/**
 * Derives the public key bytes from the secret key buffer (Sum6Kes).
 * @param {Uint8Array} sk_buffer
 * @returns {Uint8Array}
 */
function kes_to_pk(sk_buffer) {
    const ptr0 = passArray8ToWasm0(sk_buffer, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.kes_to_pk(ptr0, len0);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
}
exports.kes_to_pk = kes_to_pk;

/**
 * Updates the secret key buffer to the next period (Sum6Kes). Modifies sk_buffer in place.
 * @param {Uint8Array} sk_buffer
 */
function kes_update(sk_buffer) {
    var ptr0 = passArray8ToWasm0(sk_buffer, wasm.__wbindgen_malloc);
    var len0 = WASM_VECTOR_LEN;
    const ret = wasm.kes_update(ptr0, len0, sk_buffer);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}
exports.kes_update = kes_update;

/**
 * cool function
 * @param {Uint8Array} skey
 * @param {Uint8Array} msg
 * @returns {WasmSignature}
 */
function sign(skey, msg) {
    var ptr0 = passArray8ToWasm0(skey, wasm.__wbindgen_malloc);
    var len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(msg, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.sign(ptr0, len0, skey, ptr1, len1);
    return WasmSignature.__wrap(ret);
}
exports.sign = sign;

/**
 * cool function
 * @param {Uint8Array} sig
 * @param {number} period
 * @param {Uint8Array} pk
 * @param {Uint8Array} msg
 * @returns {boolean}
 */
function verify(sig, period, pk, msg) {
    var ptr0 = passArray8ToWasm0(sig, wasm.__wbindgen_malloc);
    var len0 = WASM_VECTOR_LEN;
    const ptr1 = passArray8ToWasm0(pk, wasm.__wbindgen_malloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passArray8ToWasm0(msg, wasm.__wbindgen_malloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.verify(ptr0, len0, sig, period, ptr1, len1, ptr2, len2);
    return ret !== 0;
}
exports.verify = verify;

exports.__wbg___wbindgen_copy_to_typed_array_db832bc4df7216c1 = function(arg0, arg1, arg2) {
    new Uint8Array(arg2.buffer, arg2.byteOffset, arg2.byteLength).set(getArrayU8FromWasm0(arg0, arg1));
};

exports.__wbg___wbindgen_throw_dd24417ed36fc46e = function(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

exports.__wbindgen_cast_2241b6af4c4b2941 = function(arg0, arg1) {
    // Cast intrinsic for `Ref(String) -> Externref`.
    const ret = getStringFromWasm0(arg0, arg1);
    return ret;
};

exports.__wbindgen_init_externref_table = function() {
    const table = wasm.__wbindgen_externrefs;
    const offset = table.grow(4);
    table.set(0, undefined);
    table.set(offset + 0, undefined);
    table.set(offset + 1, null);
    table.set(offset + 2, true);
    table.set(offset + 3, false);
};

const wasmPath = `${__dirname}/kes_summed_ed25519_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
const wasm = exports.__wasm = new WebAssembly.Instance(wasmModule, imports).exports;

wasm.__wbindgen_start();
