/* tslint:disable */
/* eslint-disable */

export class KesKeypair {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly sk: Uint8Array;
  readonly pk: Uint8Array;
}

export class Sum1CompactKesSig {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

export class Sum2CompactKesSig {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

export class Sum3CompactKesSig {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

export class Sum4CompactKesSig {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

export class Sum5CompactKesSig {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

export class Sum6CompactKesSig {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

export class Sum7CompactKesSig {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

export class WasmSignature {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}

/**
 * Gets the current period from the secret key buffer (Sum6Kes).
 */
export function kes_get_period(sk_buffer: Uint8Array): number;

/**
 * Generates a depth-6 KES key pair (Sum6Kes) from a seed.
 * Returns KesKeypair with sk_bytes (full buffer including period) and pk_bytes.
 * Suitable for Cardano operational certificates.
 */
export function kes_keygen(seed: Uint8Array): KesKeypair;

/**
 * Derives the public key bytes from the secret key buffer (Sum6Kes).
 */
export function kes_to_pk(sk_buffer: Uint8Array): Uint8Array;

/**
 * Updates the secret key buffer to the next period (Sum6Kes). Modifies sk_buffer in place.
 */
export function kes_update(sk_buffer: Uint8Array): void;

/**
 * cool function
 */
export function sign(skey: Uint8Array, msg: Uint8Array): WasmSignature;

/**
 * cool function
 */
export function verify(sig: Uint8Array, period: number, pk: Uint8Array, msg: Uint8Array): boolean;
